#include <QGuiApplication>
#include <Qt3DCore/QEntity>
#include <Qt3DRender/QSceneLoader>
#include <Qt3DExtras/Qt3DWindow>
#include <Qt3DExtras/QFirstPersonCameraController>
#include <Qt3DExtras/QOrbitCameraController>
#include <Qt3DExtras/QTextureMaterial>
#include <Qt3DRender/QCamera>
#include <Qt3DRender/QSpotLight>
#include <Qt3DRender/QPointLight>

Qt3DCore::QEntity *createScene()
{
    // Root entity
    Qt3DCore::QEntity *rootEntity = new Qt3DCore::QEntity;
    Qt3DRender::QSceneLoader *sceneLoader = new Qt3DRender::QSceneLoader(rootEntity);
    sceneLoader->setSource(QUrl(QStringLiteral("qrc:/assets/Maze.fbx")));
    rootEntity->addComponent(sceneLoader);
    return rootEntity;
}

int main(int argc, char* argv[])
{
    QGuiApplication Semana_23(argc, argv);
    Qt3DExtras::Qt3DWindow view;

    Qt3DCore::QEntity *scene = createScene();

    // Camera
    Qt3DRender::QCamera *camera = view.camera();
    camera->lens()->setPerspectiveProjection(45.0f, 16.0f/9.0f, 0.1f, 1000.0f);
    camera->setPosition(QVector3D(0, 20.0f, 40.0f));
    camera->setViewCenter(QVector3D(0, 0, 0));

    Qt3DRender::QSpotLight *luz = new Qt3DRender::QSpotLight;
    luz->setColor(QColor(255,158,0,1));

    // For camera controls
    Qt3DExtras::QFirstPersonCameraController *camController = new Qt3DExtras::QFirstPersonCameraController(scene);
    camController->setLinearSpeed( 10.0f );
    camController->setLookSpeed( 100.0f );
    camController->setCamera(camera);

    Qt3DExtras::QOrbitCameraController *orbitCamController = new Qt3DExtras::QOrbitCameraController(scene);
    orbitCamController->setLinearSpeed( 50.0f );
    orbitCamController->setLookSpeed( 180.0f );
    orbitCamController->setCamera(camera);

    view.setRootEntity(scene);
    view.show();

    return Semana_23.exec();
}
